#pragma once

// WiFi-inställningar
constexpr char DEFAULT_SSID[] = "Karstorp Mesh";
constexpr char DEFAULT_PASSWORD[] = "88ee88ee88";

// TCP-autentisering
constexpr char TCP_ADMIN_TOKEN[] = "Kopp!auppmedSesamOppnaD1g";